<section class="agenda">
  <div class="container">
    <h2 class="text-center mb-5">Conference Agenda</h2>
    <div class="row">
      <div class="col-md-4">
        <div class="agenda-item">
          <h3 class="agenda-time">9:00 AM - 10:00 AM</h3>
          <h4 class="agenda-title">Opening Keynote</h4>
          <p class="agenda-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ultricies justo ut pretium bibendum.</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="agenda-item">
          <h3 class="agenda-time">10:30 AM - 11:30 AM</h3>
          <h4 class="agenda-title">Panel Discussion</h4>
          <p class="agenda-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ultricies justo ut pretium bibendum.</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="agenda-item">
          <h3 class="agenda-time">1:00 PM - 2:00 PM</h3>
          <h4 class="agenda-title">Lunch Break</h4>
          <p class="agenda-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ultricies justo ut pretium bibendum.</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="agenda-item">
          <h3 class="agenda-time">2:30 PM - 3:30 PM</h3>
          <h4 class="agenda-title">Technical Session</h4>
          <p class="agenda-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ultricies justo ut pretium bibendum.</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="agenda-item">
          <h3 class="agenda-time">4:00 PM - 5:00 PM</h3>
          <h4 class="agenda-title">Closing Keynote</h4>
          <p class="agenda-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ultricies justo ut pretium bibendum.</p>
        </div>
      </div>
    </div>
  </div>
</section>
