<!-- partials/banner.php -->
<section class="banner">
  <div class="container">
    <h1 class="banner__title"> Bsides Fort Myers 2023</h1>
    <p class="banner__description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed eget nulla ac quam dignissim bibendum a eget orci.</p>
    <div class="row banner__boxes">
      <div class="col-md-6">
        <div class="banner__box">
          <h3 class="banner__box-title">Box 1 Title</h3>
          <p class="banner__box-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          <a href="#" class="banner__box-button">Learn More</a>
        </div>
      </div>
      <div class="col-md-6">
        <div class="banner__box">
          <h3 class="banner__box-title">Box 2 Title</h3>
          <p class="banner__box-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          <a href="#" class="banner__box-button">Learn More</a>
        </div>
      </div>
    </div>
  </div>
</section>
