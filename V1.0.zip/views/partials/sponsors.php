<section class="sponsors">
  <div class="container">
    <h2>Our Sponsors</h2>
    <div class="row">
      <div class="col-md-4 col-sm-6">
        <div class="sponsor">
          <a href="#">
            <img src="img/sponsor-1.png" alt="Sponsor 1">
          </a>
        </div>
      </div>
      <div class="col-md-4 col-sm-6">
        <div class="sponsor">
          <a href="#">
            <img src="img/sponsor-2.png" alt="Sponsor 2">
          </a>
        </div>
      </div>
      <div class="col-md-4 col-sm-6">
        <div class="sponsor">
          <a href="#">
            <img src="img/sponsor-3.png" alt="Sponsor 3">
          </a>
        </div>
      </div>
      <div class="col-md-4 col-sm-6">
        <div class="sponsor">
          <a href="#">
            <img src="img/sponsor-4.png" alt="Sponsor 4">
          </a>
        </div>
      </div>
      <div class="col-md-4 col-sm-6">
        <div class="sponsor">
          <a href="#">
            <img src="img/sponsor-5.png" alt="Sponsor 5">
          </a>
        </div>
      </div>
      <div class="col-md-4 col-sm-6">
        <div class="sponsor">
          <a href="#">
            <img src="img/sponsor-6.png" alt="Sponsor 6">
          </a>
        </div>
      </div>
    </div>
  </div>
</section>
